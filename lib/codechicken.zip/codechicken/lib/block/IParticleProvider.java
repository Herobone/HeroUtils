package codechicken.lib.block;

/**
 * Created by covers1624 on 20/11/2016.
 */
public interface IParticleProvider extends IType {

    String getParticleTexture();

}
