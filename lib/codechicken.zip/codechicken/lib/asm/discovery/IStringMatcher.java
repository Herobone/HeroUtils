package codechicken.lib.asm.discovery;

//TODO Predicate?
public interface IStringMatcher {

    boolean matches(String test);
}
