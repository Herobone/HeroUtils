package codechicken.lib.data;

/**
 * Created by covers1624 on 5/28/2016.
 */
public interface MCDataHandler extends MCDataInput, MCDataOutput {

}
