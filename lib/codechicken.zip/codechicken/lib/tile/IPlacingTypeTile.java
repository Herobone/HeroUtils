package codechicken.lib.tile;

/**
 * Created by covers1624 on 3/28/2016.
 */
//TODO Enum.
public interface IPlacingTypeTile {

    boolean getPlacing();

    void setPlacing(boolean placing);

}
