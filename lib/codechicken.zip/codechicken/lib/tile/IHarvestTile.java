package codechicken.lib.tile;

import net.minecraft.item.ItemStack;

import java.util.List;

/**
 * Created by covers1624 on 3/28/2016.
 */
public interface IHarvestTile {

    List<ItemStack> getHarvestItems();
}
