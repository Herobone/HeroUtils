package codechicken.lib.tile;

/**
 * Created by covers1624 on 7/3/2016.
 */
public interface IRedstoneActiveTile {

    void setTileActive();

    void setTileInactive();

}
