package codechicken.lib.tile;

/**
 * Created by covers1624 on 3/28/2016.
 */
public interface IActiveTile {

    boolean isActive();

    void setActive(boolean active);

}
