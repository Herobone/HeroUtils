package cofh.api.item;

public interface INBTCopyIngredient {

}
