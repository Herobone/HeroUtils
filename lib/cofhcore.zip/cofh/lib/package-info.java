/**
 * (C) 2014-2017 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API (apiVersion = CoFHLibProps.VERSION, owner = "cofhcore", provides = "cofhlib")
package cofh.lib;

import net.minecraftforge.fml.common.API;
