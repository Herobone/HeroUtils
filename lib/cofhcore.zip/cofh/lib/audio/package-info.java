/**
 * (C) 2014-2017 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API (apiVersion = CoFHLibProps.VERSION, owner = "cofhlib", provides = "cofhlib|audio")
package cofh.lib.audio;

import cofh.lib.CoFHLibProps;
import net.minecraftforge.fml.common.API;
