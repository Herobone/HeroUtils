package cofh.lib.gui;

public class GuiProps {

	/* GUI */
	public static final String PATH_GFX = "cofh:textures/";
	public static final String PATH_GUI = PATH_GFX + "gui/";
	public static final String PATH_ELEMENTS = PATH_GUI + "elements/";

	private GuiProps() {

	}

}
