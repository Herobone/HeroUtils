package mcmultipart;

import net.minecraft.entity.player.EntityPlayer;

public class MCMPCommonProxy {

    public void preInit() {

    }

    public void init() {

    }

    public EntityPlayer getPlayer() {

        return null;
    }

}
