package mcmultipart.client.multipart;

import net.minecraft.block.state.IBlockState;

public interface IMultipartColor {

    public int colorMultiplier(IBlockState state, int tintIndex);

}
