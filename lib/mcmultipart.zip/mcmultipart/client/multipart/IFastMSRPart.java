package mcmultipart.client.multipart;

import mcmultipart.multipart.IMultipart;

public interface IFastMSRPart extends IMultipart {

    public boolean hasFastRenderer();

}
