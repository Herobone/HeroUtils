package mcmultipart.item;

import net.minecraft.item.ItemStack;

public interface IItemSaw {

    public int getSawStrength(ItemStack stack);

}
