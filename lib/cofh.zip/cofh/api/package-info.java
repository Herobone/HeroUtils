/**
 * (C) 2014-2017 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API (apiVersion = CoFHAPIProps.VERSION, owner = "cofhlib", provides = "cofhapi")
package cofh.api;

import net.minecraftforge.fml.common.API;
