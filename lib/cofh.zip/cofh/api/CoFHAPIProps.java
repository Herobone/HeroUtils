package cofh.api;

public class CoFHAPIProps {

	private CoFHAPIProps() {

	}

	public static final String VERSION = "1.7.0";

}
