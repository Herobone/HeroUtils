/**
 * (C) 2014-2017 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API (apiVersion = CoFHAPIProps.VERSION, owner = "cofhapi", provides = "cofhapi|energy")
package cofh.api.energy;

import cofh.api.CoFHAPIProps;
import net.minecraftforge.fml.common.API;
